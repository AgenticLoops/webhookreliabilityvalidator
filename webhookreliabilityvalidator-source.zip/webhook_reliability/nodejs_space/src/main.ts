import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Logger } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { Request, Response, NextFunction } from 'express';

async function bootstrap() {
  const logger = new Logger('Bootstrap');

  const app = await NestFactory.create(AppModule, {
    rawBody: true,
    bodyParser: true,
  });

  // Enable CORS
  app.enableCors();

  // 1 MB payload limit
  app.use((req: Request, res: Response, next: NextFunction) => {
    const contentLength = parseInt(req.headers['content-length'] || '0', 10);
    if (contentLength > 1048576) {
      return res.status(413).json({ error: 'Payload too large. Maximum size is 1 MB.' });
    }
    next();
  });

  // Swagger setup
  const swaggerPath = 'api-docs';

  app.use(`/${swaggerPath}`, (req: Request, res: Response, next: NextFunction) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Surrogate-Control', 'no-store');
    next();
  });

  const config = new DocumentBuilder()
    .setTitle('Webhook Reliability Service')
    .setDescription('Webhook reliability and failure recovery service for Stripe webhooks')
    .setVersion('1.0')
    .addApiKey({ type: 'apiKey', name: 'X-Api-Key', in: 'header' }, 'X-Api-Key')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup(swaggerPath, app, document, {
    customSiteTitle: 'Webhook Reliability API',
    customCss: `
      .swagger-ui .topbar { display: none; }
      .swagger-ui .info .title { font-size: 2em; color: #333; }
      .swagger-ui .scheme-container { background: #fafafa; padding: 10px; }
    `,
  });

  const port = process.env.PORT || 3000;
  await app.listen(port);
  logger.log(`Webhook Reliability Service running on port ${port}`);
  logger.log(`API docs available at http://localhost:${port}/${swaggerPath}`);
}
bootstrap();
