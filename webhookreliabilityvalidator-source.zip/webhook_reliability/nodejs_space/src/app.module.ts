import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { QueueModule } from './queue/queue.module';
import { IngestModule } from './ingest/ingest.module';
import { EventsModule } from './events/events.module';
import { AdminModule } from './admin/admin.module';
import { HealthModule } from './health/health.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    QueueModule,
    IngestModule,
    EventsModule,
    AdminModule,
    HealthModule,
  ],
})
export class AppModule {}
