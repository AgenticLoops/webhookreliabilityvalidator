import { Controller, Get, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';

const QUEUE_DEPTH_ALERT_THRESHOLD = 1000;

@ApiTags('Health')
@Controller('health')
export class HealthController {
  private readonly logger = new Logger(HealthController.name);

  constructor(
    private readonly prisma: PrismaService,
    @InjectQueue('delivery') private readonly deliveryQueue: Queue,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Health check endpoint' })
  @ApiResponse({ status: 200, description: 'Health status' })
  async health() {
    let postgresStatus = 'ok';
    let redisStatus = 'ok';
    let queueDepth = 0;

    try {
      await this.prisma.$queryRaw`SELECT 1`;
    } catch {
      postgresStatus = 'error';
    }

    try {
      const counts = await this.deliveryQueue.getJobCounts();
      queueDepth = (counts.waiting || 0) + (counts.active || 0) + (counts.delayed || 0);
      redisStatus = 'ok';
    } catch {
      redisStatus = 'error';
    }

    if (queueDepth > QUEUE_DEPTH_ALERT_THRESHOLD) {
      this.logger.warn(`Queue depth alert: ${queueDepth} jobs exceed threshold of ${QUEUE_DEPTH_ALERT_THRESHOLD}`);
    }

    return {
      status: 'ok',
      queue_depth: queueDepth,
      postgres: postgresStatus,
      redis: redisStatus,
    };
  }
}
