import { Injectable, Logger, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class EventsService {
  private readonly logger = new Logger(EventsService.name);

  constructor(
    private readonly prisma: PrismaService,
    @InjectQueue('delivery') private readonly deliveryQueue: Queue,
  ) {}

  async getEvent(eventId: string, customerId: string) {
    const event = await this.prisma.events.findUnique({
      where: { id: eventId },
      include: {
        delivery_attempts: {
          orderBy: { attempt_number: 'asc' },
        },
        destination: true,
      },
    });

    if (!event) {
      throw new NotFoundException('Event not found');
    }

    if (event.destination.customer_id !== customerId) {
      throw new ForbiddenException('Access denied');
    }

    const { destination, ...eventData } = event;
    return eventData;
  }

  async replayEvent(eventId: string, customerId: string) {
    const event = await this.prisma.events.findUnique({
      where: { id: eventId },
      include: { destination: true },
    });

    if (!event) {
      throw new NotFoundException('Event not found');
    }

    if (event.destination.customer_id !== customerId) {
      throw new ForbiddenException('Access denied');
    }

    // Mark as replayed
    await this.prisma.events.update({
      where: { id: eventId },
      data: { status: 'replayed' },
    });

    // Enqueue new delivery job
    await this.deliveryQueue.add('deliver', {
      eventId: event.id,
      destinationId: event.destination_id,
      isReplay: true,
    }, {
      attempts: 5,
      backoff: {
        type: 'custom',
      },
    });

    this.logger.log(`Event ${eventId} queued for replay`);
    return { status: 'queued_for_replay', event_id: eventId };
  }
}
