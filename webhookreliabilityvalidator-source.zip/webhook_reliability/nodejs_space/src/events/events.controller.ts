import { Controller, Get, Post, Param, Req, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { EventsService } from './events.service';
import { ApiKeyGuard } from '../common/auth.guard';
import { ApiTags, ApiOperation, ApiHeader, ApiParam, ApiResponse } from '@nestjs/swagger';

@ApiTags('Events')
@Controller('events')
export class EventsController {
  constructor(private readonly eventsService: EventsService) {}

  @Get(':id')
  @UseGuards(ApiKeyGuard)
  @ApiOperation({ summary: 'Get event details with delivery attempts' })
  @ApiHeader({ name: 'X-Api-Key', required: true })
  @ApiParam({ name: 'id', description: 'Event UUID' })
  @ApiResponse({ status: 200, description: 'Event details with delivery attempts' })
  @ApiResponse({ status: 403, description: 'Access denied' })
  @ApiResponse({ status: 404, description: 'Event not found' })
  async getEvent(@Param('id') id: string, @Req() req: any) {
    const customer = req.customer;
    return this.eventsService.getEvent(id, customer.id);
  }

  @Post(':id/replay')
  @UseGuards(ApiKeyGuard)
  @HttpCode(HttpStatus.ACCEPTED)
  @ApiOperation({ summary: 'Replay a failed event' })
  @ApiHeader({ name: 'X-Api-Key', required: true })
  @ApiParam({ name: 'id', description: 'Event UUID' })
  @ApiResponse({ status: 202, description: 'Event queued for replay' })
  @ApiResponse({ status: 403, description: 'Access denied' })
  @ApiResponse({ status: 404, description: 'Event not found' })
  async replayEvent(@Param('id') id: string, @Req() req: any) {
    const customer = req.customer;
    return this.eventsService.replayEvent(id, customer.id);
  }
}
