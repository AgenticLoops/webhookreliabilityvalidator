import { encryptSecret, decryptSecret } from './encryption';

describe('Encryption Helpers', () => {
  beforeAll(() => {
    process.env.APP_SECRET = 'test-secret-for-encryption-32chars!';
  });

  it('should encrypt and decrypt returning original value', () => {
    const plaintext = 'whsec_my_secret_key_12345';
    const encrypted = encryptSecret(plaintext);
    const decrypted = decryptSecret(encrypted);
    expect(decrypted).toBe(plaintext);
  });

  it('should produce different ciphertexts for the same input (random IV/salt)', () => {
    const plaintext = 'whsec_same_secret';
    const enc1 = encryptSecret(plaintext);
    const enc2 = encryptSecret(plaintext);
    expect(enc1).not.toBe(enc2);
    // But both decrypt to same value
    expect(decryptSecret(enc1)).toBe(plaintext);
    expect(decryptSecret(enc2)).toBe(plaintext);
  });

  it('should handle empty strings', () => {
    const encrypted = encryptSecret('');
    expect(decryptSecret(encrypted)).toBe('');
  });

  it('should handle unicode content', () => {
    const plaintext = 'webhook_secret_🔑_测试';
    const encrypted = encryptSecret(plaintext);
    expect(decryptSecret(encrypted)).toBe(plaintext);
  });
});
