import { CanActivate, ExecutionContext, Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class ApiKeyGuard implements CanActivate {
  private readonly logger = new Logger(ApiKeyGuard.name);

  constructor(private readonly prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const apiKey = request.headers['x-api-key'];

    if (!apiKey) {
      throw new UnauthorizedException('Missing X-Api-Key header');
    }

    const customers = await this.prisma.customers.findMany();
    for (const customer of customers) {
      const match = await bcrypt.compare(apiKey, customer.api_key_hash);
      if (match) {
        request.customer = customer;
        return true;
      }
    }

    this.logger.warn('Invalid API key attempted');
    throw new UnauthorizedException('Invalid API key');
  }
}
