import { createHash } from 'crypto';

describe('Deduplication Logic', () => {
  const computeHash = (payload: string) =>
    createHash('sha256').update(payload).digest('hex');

  it('should produce same hash for identical payloads', () => {
    const payload = '{"type":"invoice.paid","data":{"id":"inv_123"}}';
    const hash1 = computeHash(payload);
    const hash2 = computeHash(payload);
    expect(hash1).toBe(hash2);
  });

  it('should produce different hash for different payloads', () => {
    const hash1 = computeHash('{"type":"invoice.paid"}');
    const hash2 = computeHash('{"type":"invoice.created"}');
    expect(hash1).not.toBe(hash2);
  });

  describe('24-hour dedup window', () => {
    it('same hash within 24h should be considered duplicate', () => {
      const now = Date.now();
      const receivedAt = new Date(now - 1 * 60 * 60 * 1000); // 1 hour ago
      const cutoff = new Date(now - 24 * 60 * 60 * 1000);
      expect(receivedAt.getTime()).toBeGreaterThanOrEqual(cutoff.getTime());
    });

    it('same hash older than 24h should NOT be duplicate', () => {
      const now = Date.now();
      const receivedAt = new Date(now - 25 * 60 * 60 * 1000); // 25 hours ago
      const cutoff = new Date(now - 24 * 60 * 60 * 1000);
      expect(receivedAt.getTime()).toBeLessThan(cutoff.getTime());
    });
  });
});
