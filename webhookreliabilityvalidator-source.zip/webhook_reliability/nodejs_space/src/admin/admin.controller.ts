import { Controller, Post, Body, Req, UseGuards } from '@nestjs/common';
import { AdminService } from './admin.service';
import { ApiKeyGuard } from '../common/auth.guard';
import { ApiTags, ApiOperation, ApiHeader, ApiBody, ApiResponse } from '@nestjs/swagger';

@ApiTags('Admin')
@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Post('destinations')
  @UseGuards(ApiKeyGuard)
  @ApiOperation({ summary: 'Create a new webhook destination' })
  @ApiHeader({ name: 'X-Api-Key', required: true })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        target_url: { type: 'string', example: 'https://example.com/webhook' },
        secret: { type: 'string', example: 'whsec_test_secret' },
      },
      required: ['target_url', 'secret'],
    },
  })
  @ApiResponse({ status: 201, description: 'Destination created' })
  async createDestination(
    @Body() body: { target_url: string; secret: string },
    @Req() req: any,
  ) {
    const customer = req.customer;
    return this.adminService.createDestination(customer.id, body.target_url, body.secret);
  }
}
