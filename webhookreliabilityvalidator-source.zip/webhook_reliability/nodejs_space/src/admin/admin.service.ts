import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { encryptSecret } from '../common/encryption';

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  constructor(private readonly prisma: PrismaService) {}

  async createDestination(customerId: string, targetUrl: string, secret: string) {
    const encryptedSecret = encryptSecret(secret);

    const destination = await this.prisma.destinations.create({
      data: {
        customer_id: customerId,
        target_url: targetUrl,
        secret: encryptedSecret,
        active: true,
      },
    });

    this.logger.log(`Destination ${destination.id} created for customer ${customerId}`);
    return { id: destination.id, target_url: destination.target_url, active: destination.active };
  }
}
