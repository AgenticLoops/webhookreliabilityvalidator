import { Injectable, Logger, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from '../prisma/prisma.service';
import { createHash } from 'crypto';
import Stripe from 'stripe';
import { decryptSecret } from '../common/encryption';

@Injectable()
export class IngestService {
  private readonly logger = new Logger(IngestService.name);
  private readonly stripe: Stripe;

  constructor(
    private readonly prisma: PrismaService,
    @InjectQueue('delivery') private readonly deliveryQueue: Queue,
  ) {
    // We only use the webhooks.constructEvent method, which doesn't need a real API key
    this.stripe = new Stripe('sk_not_used');
  }

  async ingest(destinationId: string, rawBody: Buffer, signatureHeader: string) {
    // Look up destination
    const destination = await this.prisma.destinations.findUnique({
      where: { id: destinationId },
    });

    if (!destination || !destination.active) {
      throw new NotFoundException('Destination not found or inactive');
    }

    // Decrypt secret and verify Stripe signature
    const secret = decryptSecret(destination.secret);
    try {
      this.stripe.webhooks.constructEvent(rawBody, signatureHeader, secret);
    } catch (err: any) {
      this.logger.warn(`Stripe signature verification failed for destination ${destinationId}: ${err.message}`);
      throw new BadRequestException('Invalid Stripe signature');
    }

    const rawPayloadStr = rawBody.toString('utf8');

    // Compute SHA-256 hash
    const payloadHash = createHash('sha256').update(rawBody).digest('hex');

    // Check deduplication: same hash within 24h for this destination
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const duplicate = await this.prisma.events.findFirst({
      where: {
        destination_id: destinationId,
        payload_hash: payloadHash,
        received_at: { gte: twentyFourHoursAgo },
      },
    });

    if (duplicate) {
      this.logger.log(`Duplicate payload detected for destination ${destinationId}, event ${duplicate.id}`);
      return { status: 'duplicate', event_id: duplicate.id };
    }

    // Insert event
    const event = await this.prisma.events.create({
      data: {
        destination_id: destinationId,
        provider: 'stripe',
        raw_payload: rawPayloadStr,
        payload_hash: payloadHash,
        signature_valid: true,
        status: 'pending',
      },
    });

    // Enqueue BullMQ job
    await this.deliveryQueue.add('deliver', {
      eventId: event.id,
      destinationId: destinationId,
    }, {
      attempts: 5,
      backoff: {
        type: 'custom',
      },
    });

    this.logger.log(`Event ${event.id} accepted for destination ${destinationId}`);
    return { status: 'accepted', event_id: event.id };
  }
}
