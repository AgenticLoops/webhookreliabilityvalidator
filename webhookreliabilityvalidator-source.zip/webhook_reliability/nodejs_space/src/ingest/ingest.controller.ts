import { Controller, Post, Param, Req, Res, HttpStatus, Logger } from '@nestjs/common';
import type { Request, Response } from 'express';
import { IngestService } from './ingest.service';
import { ApiTags, ApiOperation, ApiParam, ApiResponse } from '@nestjs/swagger';

@ApiTags('Ingest')
@Controller('ingest')
export class IngestController {
  private readonly logger = new Logger(IngestController.name);

  constructor(private readonly ingestService: IngestService) {}

  @Post(':destination_id')
  @ApiOperation({ summary: 'Ingest a Stripe webhook event' })
  @ApiParam({ name: 'destination_id', description: 'Destination UUID' })
  @ApiResponse({ status: 200, description: 'Event accepted or duplicate detected' })
  @ApiResponse({ status: 400, description: 'Invalid Stripe signature' })
  @ApiResponse({ status: 413, description: 'Payload too large' })
  @ApiResponse({ status: 503, description: 'Service unavailable' })
  async ingest(
    @Param('destination_id') destinationId: string,
    @Req() req: any,
    @Res() res: any,
  ) {
    try {
      const rawBody = req.rawBody as Buffer;
      if (!rawBody) {
        return res.status(HttpStatus.BAD_REQUEST).json({ error: 'Missing raw body' });
      }

      const signature = req.headers['stripe-signature'] as string;
      if (!signature) {
        this.logger.warn('Missing Stripe signature header');
        return res.status(HttpStatus.BAD_REQUEST).json({ error: 'Missing stripe-signature header' });
      }

      const result = await this.ingestService.ingest(destinationId, rawBody, signature);
      return res.status(HttpStatus.OK).json(result);
    } catch (err: any) {
      if (err.status === 400) {
        return res.status(HttpStatus.BAD_REQUEST).json({ error: err.message });
      }
      if (err.status === 404) {
        return res.status(HttpStatus.NOT_FOUND).json({ error: err.message });
      }
      this.logger.error(`Ingestion error: ${err.message}`, err.stack);
      return res.status(HttpStatus.SERVICE_UNAVAILABLE).json({ error: 'Service temporarily unavailable' });
    }
  }
}
