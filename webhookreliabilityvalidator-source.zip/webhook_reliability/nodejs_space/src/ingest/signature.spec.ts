import Stripe from 'stripe';

describe('Stripe Signature Verification', () => {
  const stripe = new Stripe('sk_test_fake');
  const secret = 'whsec_test_secret_for_verification';

  function generateSignature(payload: string, secret: string): string {
    const timestamp = Math.floor(Date.now() / 1000);
    const crypto = require('crypto');
    const signedPayload = `${timestamp}.${payload}`;
    const expectedSig = crypto
      .createHmac('sha256', secret)
      .update(signedPayload)
      .digest('hex');
    return `t=${timestamp},v1=${expectedSig}`;
  }

  it('should accept valid Stripe signature', () => {
    const payload = '{"type":"checkout.session.completed"}';
    const signature = generateSignature(payload, secret);
    const event = stripe.webhooks.constructEvent(payload, signature, secret);
    expect(event).toBeDefined();
    expect(event.type).toBe('checkout.session.completed');
  });

  it('should reject tampered payload', () => {
    const payload = '{"type":"checkout.session.completed"}';
    const signature = generateSignature(payload, secret);
    const tamperedPayload = '{"type":"checkout.session.completed","hacked":true}';
    expect(() => {
      stripe.webhooks.constructEvent(tamperedPayload, signature, secret);
    }).toThrow();
  });

  it('should reject missing signature', () => {
    const payload = '{"type":"test"}';
    expect(() => {
      stripe.webhooks.constructEvent(payload, '', secret);
    }).toThrow();
  });
});
