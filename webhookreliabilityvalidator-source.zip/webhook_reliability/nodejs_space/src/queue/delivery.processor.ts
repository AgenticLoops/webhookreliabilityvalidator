import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from '../prisma/prisma.service';
import { decryptSecret } from '../common/encryption';
import axios from 'axios';

const BACKOFF_DELAYS = [30000, 60000, 120000, 240000, 480000]; // 30s, 60s, 120s, 240s, 480s

@Processor('delivery', {
  settings: {
    backoffStrategy: (attemptsMade: number) => {
      const index = Math.min(attemptsMade - 1, BACKOFF_DELAYS.length - 1);
      return BACKOFF_DELAYS[index];
    },
  },
})
export class DeliveryProcessor extends WorkerHost {
  private readonly logger = new Logger(DeliveryProcessor.name);

  constructor(private readonly prisma: PrismaService) {
    super();
  }

  async process(job: Job<{ eventId: string; destinationId: string; isReplay?: boolean }>): Promise<void> {
    const { eventId, destinationId, isReplay } = job.data;
    const attemptNumber = job.attemptsMade + 1;

    this.logger.log(`Processing delivery for event ${eventId}, attempt ${attemptNumber}`);

    const event = await this.prisma.events.findUnique({ where: { id: eventId } });
    const destination = await this.prisma.destinations.findUnique({ where: { id: destinationId } });

    if (!event || !destination) {
      this.logger.error(`Event ${eventId} or destination ${destinationId} not found`);
      return;
    }

    let responseCode: number | null = null;
    let responseBody: string | null = null;
    let succeeded = false;

    try {
      // Build the payload to send
      let payload: any = JSON.parse(event.raw_payload);
      if (isReplay) {
        payload = { ...payload, replayed: true };
      }

      const response = await axios.post(destination.target_url, payload, {
        timeout: 10000,
        headers: { 'Content-Type': 'application/json' },
        validateStatus: () => true, // Don't throw on non-2xx
      });

      responseCode = response.status;
      responseBody = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
      succeeded = responseCode >= 200 && responseCode < 300;
    } catch (err: any) {
      this.logger.warn(`Delivery failed for event ${eventId}: ${err.message}`);
      responseBody = err.message;
    }

    // Record delivery attempt
    await this.prisma.delivery_attempts.create({
      data: {
        event_id: eventId,
        attempt_number: attemptNumber,
        response_code: responseCode,
        response_body: responseBody,
        succeeded,
      },
    });

    if (succeeded) {
      await this.prisma.events.update({
        where: { id: eventId },
        data: { status: 'delivered' },
      });
      this.logger.log(`Event ${eventId} delivered successfully on attempt ${attemptNumber}`);
    } else if (attemptNumber >= 5) {
      await this.prisma.events.update({
        where: { id: eventId },
        data: { status: 'failed' },
      });
      this.logger.error(`Event ${eventId} failed after ${attemptNumber} attempts`);
    } else {
      // Throw to trigger BullMQ retry
      throw new Error(`Delivery failed with code ${responseCode}: ${responseBody}`);
    }
  }
}
