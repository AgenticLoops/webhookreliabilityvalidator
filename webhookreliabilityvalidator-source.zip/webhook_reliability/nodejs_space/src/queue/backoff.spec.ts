describe('Retry Backoff Delays', () => {
  const BACKOFF_DELAYS = [30000, 60000, 120000, 240000, 480000];

  const backoffStrategy = (attemptsMade: number) => {
    const index = Math.min(attemptsMade - 1, BACKOFF_DELAYS.length - 1);
    return BACKOFF_DELAYS[index];
  };

  it('attempt 1 should have 30s delay', () => {
    expect(backoffStrategy(1)).toBe(30000);
  });

  it('attempt 2 should have 60s delay', () => {
    expect(backoffStrategy(2)).toBe(60000);
  });

  it('attempt 3 should have 120s delay', () => {
    expect(backoffStrategy(3)).toBe(120000);
  });

  it('attempt 4 should have 240s delay', () => {
    expect(backoffStrategy(4)).toBe(240000);
  });

  it('attempt 5 should have 480s delay', () => {
    expect(backoffStrategy(5)).toBe(480000);
  });
});
